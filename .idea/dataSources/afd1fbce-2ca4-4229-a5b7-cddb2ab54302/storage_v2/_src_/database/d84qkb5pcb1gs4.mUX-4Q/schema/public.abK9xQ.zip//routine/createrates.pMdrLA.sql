create function createrates(bid integer) returns void
    language plpgsql
as
$$
BEGIN
        INSERT INTO rates (bookstoreid) values (bid);
    END;
$$;

alter function createrates(integer) owner to fzackjzcncjwff;

