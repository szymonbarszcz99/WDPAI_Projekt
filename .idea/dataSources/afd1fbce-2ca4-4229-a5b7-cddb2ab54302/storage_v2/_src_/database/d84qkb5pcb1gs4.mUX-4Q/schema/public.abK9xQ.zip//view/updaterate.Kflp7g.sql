create view updaterate(id, rate, numberofrates, sumofrates) as
SELECT bookstores.id,
       bookstores.rate,
       rates.numberofrates,
       rates.sumofrates
FROM bookstores
         LEFT JOIN rates ON bookstores.id = rates.bookstoreid;

alter table updaterate
    owner to fzackjzcncjwff;

