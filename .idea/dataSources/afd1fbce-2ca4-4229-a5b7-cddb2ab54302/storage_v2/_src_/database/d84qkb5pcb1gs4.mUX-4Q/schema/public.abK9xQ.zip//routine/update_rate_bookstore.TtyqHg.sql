create function update_rate_bookstore() returns trigger
    language plpgsql
as
$$
BEGIN
        UPDATE bookstores SET rate=(CAST(NEW.sumofrates AS FLOAT))/(CAST(new.numberofrates*5.0 AS FLOAT)) WHERE bookstores.id=OLD.bookstoreid;
        RETURN NULL;
    END;
$$;

alter function update_rate_bookstore() owner to fzackjzcncjwff;

