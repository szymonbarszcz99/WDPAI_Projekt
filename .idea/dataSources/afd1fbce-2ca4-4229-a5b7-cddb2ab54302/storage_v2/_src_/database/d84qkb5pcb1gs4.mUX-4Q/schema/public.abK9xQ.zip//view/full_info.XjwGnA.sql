create view full_info
            (id, name, address, telephone, webpage, description, photos, rate, opening_hours_id, mon, tue, wed, thur,
             fri, sat, sun)
as
SELECT bookstores.id,
       bookstores.name,
       bookstores.address,
       bookstores.telephone,
       bookstores.webpage,
       bookstores.description,
       bookstores.photos,
       bookstores.rate,
       bookstores.opening_hours_id,
       opening_hours.mon,
       opening_hours.tue,
       opening_hours.wed,
       opening_hours.thur,
       opening_hours.fri,
       opening_hours.sat,
       opening_hours.sun
FROM bookstores
         LEFT JOIN opening_hours ON opening_hours.id = bookstores.opening_hours_id;

alter table full_info
    owner to fzackjzcncjwff;

