create view quick_info(id, name, rate, address, description, photos) as
SELECT bookstores.id,
       bookstores.name,
       bookstores.rate,
       bookstores.address,
       bookstores.description,
       bookstores.photos
FROM bookstores;

alter table quick_info
    owner to fzackjzcncjwff;

